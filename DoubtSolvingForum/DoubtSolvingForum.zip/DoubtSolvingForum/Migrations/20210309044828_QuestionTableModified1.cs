﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DoubtSolvingForum.Migrations
{
    public partial class QuestionTableModified1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
